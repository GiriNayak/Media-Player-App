package com.devbrackets.android.exomediademo.ui.support.compose.theme

import androidx.compose.material3.Shapes
import androidx.compose.runtime.staticCompositionLocalOf

internal val LocalShapes = staticCompositionLocalOf { Shapes() }
