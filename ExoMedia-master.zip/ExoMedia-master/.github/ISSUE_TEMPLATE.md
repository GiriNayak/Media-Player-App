### Environment:
 - ExoMedia version: `5.0.0`
 - Device OS version: `12.0`
 - Device Manufacturer: `Google`
 - Device Name: `Pixel 7 Pro`
 
### Reproduction Steps
 0.  

#### Expected Result

#### Actual Result
